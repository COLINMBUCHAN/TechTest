﻿namespace MyApp.Models.Base
{
    public abstract class ModelBase
    {
        public long Id { get; internal set; }
    }
}
