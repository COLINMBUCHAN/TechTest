﻿/// <reference path="jquery-ui-1.13.2.js" />
/// <reference path="jquery-2.0.0.js" />
/// <autosync enabled="true" />
/// <reference path="modernizr-2.6.2.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="bootstrap.js" />
/// <reference path="respond.js" />
